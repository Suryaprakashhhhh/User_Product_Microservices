package com.product.repository;

import com.product.model.Stock;

public interface StockRepository {

	Stock save(Stock stock);

}
