package com.product.serviceinterface;

import com.product.model.Stock;

public interface StockInterface {
	public Stock saveStock(Stock Stock);
}
