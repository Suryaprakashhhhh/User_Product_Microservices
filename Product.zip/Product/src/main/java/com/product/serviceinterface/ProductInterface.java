package com.product.serviceinterface;

import com.product.model.Product;

public interface ProductInterface {
	public Product getProductById(int id);
}
